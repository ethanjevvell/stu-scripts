﻿namespace IngameScript {
    partial class Program {
        public partial class LIGMA {

            public class SpaceToSpaceFlightPlan : IFlightPlan {

                public override bool Run() {
                    return true;
                }

            }

        }
    }
}
