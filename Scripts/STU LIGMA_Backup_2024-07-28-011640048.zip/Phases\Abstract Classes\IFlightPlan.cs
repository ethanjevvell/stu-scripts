﻿namespace IngameScript {
    partial class Program {
        public partial class LIGMA {
            public abstract class IFlightPlan {
                public abstract bool Run();
            }
        }
    }
}
