﻿namespace IngameScript {
    partial class Program {
        public partial class LIGMA {
            public class PlanetToSpaceDescentPlan : IDescentPlan {
                public override bool Run() {
                    FirstRunTasks();
                    return true;
                }
            }
        }
    }
}

