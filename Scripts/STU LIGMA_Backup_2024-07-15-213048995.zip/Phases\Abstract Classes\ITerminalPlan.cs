﻿namespace IngameScript {
    partial class Program {
        public partial class LIGMA {
            public abstract class ITerminalPlan {
                public abstract bool Run();
            }
        }
    }
}

